/*
 * @Author: M.H
 * @Date: 2022-11-10 14:55:17
 * @LastEditors: M.H
 * @LastEditTime: 2022-11-10 15:21:23
 * @Description: 请填写简介
 */
export default {
  label: '数组',
  type: 'array',
  property: '',
  value: [],
  child: [],
  options: {
    note: '',
    limit: 10,
  },
};
